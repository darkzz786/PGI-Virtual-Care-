package com.myproject.PGIVirtualcare.Controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.myproject.PGIVirtualcare.API.SendAutoEmail;
import com.myproject.PGIVirtualcare.Model.Appointment;
import com.myproject.PGIVirtualcare.Model.Appointment.AppointmentStatus;
import com.myproject.PGIVirtualcare.Model.Prescription;
import com.myproject.PGIVirtualcare.Model.Users;
import com.myproject.PGIVirtualcare.Model.Users.UserROle;
import com.myproject.PGIVirtualcare.Model.Users.UserStatus;
import com.myproject.PGIVirtualcare.Repository.AppointmentRepository;
import com.myproject.PGIVirtualcare.Repository.PrescriptionRepository;
import com.myproject.PGIVirtualcare.Repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/Doctor")
public class DoctorController {

	@Autowired
	private HttpSession session;
	 
	@Autowired
	private AppointmentRepository appointmentRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	
	@Autowired
	private PrescriptionRepository prescriptionRepo;
	
	
	@Autowired
	private SendAutoEmail sendAutoEmail;
	
	@GetMapping("/DoctorDashboard")
	public String showdashboard() {
		
		if (session.getAttribute("loggedInDoctor") == null) {
			return "redirect:/Doctor";
		}
		
		return "Doctor/DoctorDashboard";
	}
	
	
	@GetMapping("/Appointments")
	public String showappointment(Model model) {
		
		if (session.getAttribute("loggedInDoctor") == null) {
			return "redirect:/Doctor";
		}
		Users doctor=(Users) session.getAttribute("loggedInDoctor");
		List<Appointment> applist=appointmentRepo.findAllByDoctor(doctor);
		model.addAttribute("applist", applist);
		
		return "Doctor/Appointments";
	}
	
	@GetMapping("/AptStatus")
	public String updateappstatus(@RequestParam("id") long id ,RedirectAttributes attributes) {
		try {
			
		       Appointment app=appointmentRepo.findById(id).get();
			if (app.getStatus().equals(AppointmentStatus.PENDING)) {
				app.setStatus(AppointmentStatus.APPROVED);
				appointmentRepo.save(app);
				
			}
			else if (app.getStatus().equals(AppointmentStatus.APPROVED)) {
				app.setStatus(AppointmentStatus.PENDING);
				appointmentRepo.save(app);
			}
			else {
				app.setStatus(AppointmentStatus.APPROVED);
				appointmentRepo.save(app);
			}
			
			
			attributes.addFlashAttribute("msg", "User Status Successfully Updated");
			return "redirect:/Doctor/Appointments";
		} catch (Exception e) {
			return "redirect:/Doctor/Appointments";
		}
		
		
		
		
	}
	
	
	
	
	@GetMapping("/WritePrescription")
	public String showWritePrescription(@RequestParam("id") long id , Model model) {
		
		if (session.getAttribute("loggedInDoctor") == null) {
			return "redirect:/Doctor";
		}
		
		
		Appointment  appointment =appointmentRepo.findById(id).get();
		model.addAttribute("appointment", appointment);
		
		Prescription  prescription=new Prescription();
		model.addAttribute("prescription", prescription);
		
		return "Doctor/WritePrescription";
	}

	
	
	@PostMapping("/WritePrescription")
	public String WritePrescription(@ModelAttribute("prescription") Prescription prescription ,RedirectAttributes attributes ,@RequestParam("appointmentId") long appointmentId) {
		
		
		try {
			Appointment appointment=appointmentRepo.findById(appointmentId).get();
			
			prescription.setAppointment(appointment);
			prescription.setDoctor(appointment.getDoctor());
			prescription.setPatient(appointment.getPatient());
			
			prescription.setPrescirptionDate(LocalDateTime.now());
			prescriptionRepo.save(prescription);
			attributes.addFlashAttribute("msg", "prescripption Successfully submited");
			
			
			
			return "redirect:/Doctor/Appointments";
		} catch (Exception e) {
			
			attributes.addFlashAttribute("msg", e.getMessage());
			return "redirect:/Doctor/WritePrescription?id="+appointmentId;
		}
	}
	
	
	
	@GetMapping("/Logout")
	public String logout(RedirectAttributes attributes) {
		session.removeAttribute("loggedInDoctor");
		attributes.addFlashAttribute("msg", "Logout Successful");
		return "redirect:/Doctor";

	}

	
	@GetMapping("/ChangePassword")
	public String Changepassword() {
		if (session.getAttribute("loggedInDoctor") == null) {
			return "redirect:/Doctor";
		}

		return "Doctor/ChangePassword";

	}

	@PostMapping("/ChangePassword")
	public String changepasssword(HttpServletRequest request, RedirectAttributes attributes) {

		try {
			String oldPass = request.getParameter("oldPassword");
			String newPass = request.getParameter("newPassword");
			String confirmPass = request.getParameter("confirmPassword");

			if (!newPass.equals(confirmPass)) {
				attributes.addFlashAttribute("msg", "New Password and confirm Password are not Same!");
				return "redirect:/Admin/ChangePassword";
			}
			Users doctor = (Users) session.getAttribute("loggedInDoctor");
			if (oldPass.equals(doctor.getPassword())) {
				doctor.setPassword(confirmPass);
				userRepo.save(doctor);
				session.removeAttribute("loggedInDoctor");
				attributes.addFlashAttribute("msg", "Password Successfully Change");
				return "redirect:/Doctor";

			} else {
				attributes.addFlashAttribute("msg", "Invalid Old Password");

			}

			return "redirect:/Doctor/ChangePassword";

		} catch (Exception e) {
			attributes.addFlashAttribute("msg", "Error :" + e.getMessage());
			return "redirect:/Doctor/ChangePassword";
		}
	}

	

	
}
