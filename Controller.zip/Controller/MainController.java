package com.myproject.PGIVirtualcare.Controller;

import java.time.LocalDateTime;

import org.hibernate.query.sqm.internal.SqmQueryPartCreationProcessingStateStandardImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.myproject.PGIVirtualcare.Model.Enquiry;
import com.myproject.PGIVirtualcare.Model.Users;
import com.myproject.PGIVirtualcare.Model.Users.UserROle;
import com.myproject.PGIVirtualcare.Model.Users.UserStatus;
import com.myproject.PGIVirtualcare.Repository.EnquiryRepository;
import com.myproject.PGIVirtualcare.Repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private EnquiryRepository enquiryRepo;

	private Enquiry enquiry;

	@GetMapping("/")
	public String showindex() {
		return "index";
	}

	@GetMapping("/AboutUs")
	public String showaboutus()

	{
		return "aboutus";
	}

	@GetMapping("/Services")
	public String showservices()

	{
		return "services";
	}

	@GetMapping("/ContactUs")
	public String showContactUs(Model model) {

		Enquiry enquiry = new Enquiry();
		model.addAttribute("enquiry", enquiry);
		return "contactus";
	}

	@PostMapping("/ContactUs")
	public String SubmitEnquiry(@ModelAttribute("enquiry") Enquiry enquiry, RedirectAttributes attributes) {

		try {

			enquiry.setEnquiryDate(LocalDateTime.now());
			enquiryRepo.save(enquiry);
			attributes.addFlashAttribute("msg", "Message Send Successful");
			return "redirect:/ContactUs";

		} catch (Exception e) {

			attributes.addFlashAttribute("msg", "error :" + e.getMessage());
			return "redirect:/ContactUs";
		}
	}
	
	
	

	@GetMapping("/Ragistration")
	public String showagistration(Model model) {
		Users userDto = new Users(); 
		model.addAttribute("userDto", userDto);

		return "ragistration";
	}

	@PostMapping("/Ragistration")
	public String Registration(@ModelAttribute("userDto") Users newUser, RedirectAttributes attributes) {
		try {
			newUser.setRole(UserROle.PATIENT);
			newUser.setStatus(UserStatus.PENDING);
			newUser.setRegDate(LocalDateTime.now());
			userRepo.save(newUser);
			attributes.addFlashAttribute("msg", "Registration Successful");

			return "redirect:/Ragistration";

		} catch (Exception e) {

			attributes.addFlashAttribute("msg", "Error: " + e.getMessage());

			return "redirect:/Ragistration";

		}

	}
	// Login page

	@GetMapping("/Admin")
	public String showadmin() {
		return "admin";
	}

	
	
	
	
	
	
	
	
	
	@PostMapping("/Admin")
	public String showadmindata(HttpServletRequest request, RedirectAttributes attributes, HttpSession session) {

		try {

			String email = request.getParameter("email");
			String password = request.getParameter("password");

			if (!userRepo.existsByEmail(email))
			{
				attributes.addFlashAttribute("msg", "User not exixts!");
				return "redirect:/admin";

			}

			Users admin = userRepo.findByEmail(email);

			if (password.equals(admin.getPassword()) && admin.getRole().equals(UserROle.ADMIN))
			{
				
				
				session.setAttribute("loggedInAdmin", admin);
				return "redirect:/Admin/AdminDashboard";
			
			}
			
			else 
			{
				
			attributes.addFlashAttribute("msg", "Invalid Password or Username");	
				
			}
			return "redirect:/Admin";

		} catch (Exception e) {
			

			attributes.addFlashAttribute("msg","Error"+e.getMessage());
			return "redirect:/Admin";

		}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// patient login

	@GetMapping("/Patient")
	public String showpatient() {

		return "patient";
	}

	@PostMapping("/Patient")
	public String showpatientdata(HttpServletRequest request, RedirectAttributes attributes ,HttpSession session) {

		try {

			String email = request.getParameter("email");
			String password = request.getParameter("password");

			if (!userRepo.existsByEmail(email)) {
				attributes.addFlashAttribute("msg", "User not exixts!");
				return "redirect:/Patient";

			}

			Users patient = userRepo.findByEmail(email);

			if (password.equals(patient.getPassword()) && patient.getRole().equals(UserROle.PATIENT))
			
			{
				
		if(patient.getStatus().equals(UserStatus.PENDING))
		{
			
			attributes.addFlashAttribute("msg","Registration Pending Wait For Admin Approval");		
			
		}
		
		else if(patient.getStatus().equals(UserStatus.DISABLE)) 
			
			{
				attributes.addFlashAttribute("msg","Login Disable 🚫, pls Contact Adminitration");	
			}
			else
			{
				
					
				session.setAttribute("loggedInPatient", patient);
				return "redirect:/Patient/PatientDashboard";

				

			}
			}
			else 
			{
				
			attributes.addFlashAttribute("msg", "Invalid Users or Password");	
				
			}
			return "redirect:/Patient";

		} catch (Exception e) {

			return "redirect:/Patient";

		}

	}

	@GetMapping("/Doctor")
	public String showdoctor() {
		return "doctor";
	}
	
	@PostMapping("/Doctor")
	public String showdoctordata(HttpServletRequest request,RedirectAttributes  attributes ,HttpSession session) {
		try {
			String email=request.getParameter("email");
			String password=request.getParameter("password");
			if (!userRepo.existsByEmail(email)) {
				attributes.addFlashAttribute("msg","doctor does not exist" );
				return "redirect:/Doctor";
			}
			
			Users doctor=userRepo.findByEmail(email);
			if (password.equals(doctor.getPassword()) && doctor.getRole().equals(UserROle.Doctor)) {
				if(doctor.getStatus().equals(UserStatus.DISABLE))
				{
					
					attributes.addFlashAttribute("msg","Disable");		
					
				}
				else {
					session.setAttribute("loggedInDoctor", doctor);
					return "redirect:/Doctor/DoctorDashboard";
					
					
				}
			}
				else {
					attributes.addFlashAttribute("msg","Invalid User or Wrong Password");
				}
			
			
			
			return "redirect:/Doctor";
		} catch (Exception e) {
			
			return "redirect:/Doctor";
		}
	}
	
}
