package com.myproject.PGIVirtualcare.Controller;



import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.myproject.PGIVirtualcare.Model.Appointment;
import com.myproject.PGIVirtualcare.Model.Appointment.AppointmentStatus;
import com.myproject.PGIVirtualcare.Model.Prescription;
import com.myproject.PGIVirtualcare.Model.Users;
import com.myproject.PGIVirtualcare.Model.Users.UserROle;
import com.myproject.PGIVirtualcare.Repository.AppointmentRepository;
import com.myproject.PGIVirtualcare.Repository.PrescriptionRepository;
import com.myproject.PGIVirtualcare.Repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/Patient")
public class PatientController {

	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private UserRepository userRepo;
	   
	
	
	@Autowired
	public AppointmentRepository appointmentRepo;
	
	@Autowired
	public PrescriptionRepository prescriptionRepo;
	
	
	@GetMapping("/PatientDashboard")
	public String showpatientdashboard() {
		if (session.getAttribute("loggedInPatient")==null) {
			return "redirect:/Patient";
			
		}
		
		
	    
		
		
		return "Patient/PatientDashboard";
	}
	
	
	
	
	
	
	
	@GetMapping("/Bookappointment")
	public String showbookappointment(Model model) {
		
		if (session.getAttribute("loggedInPatient")==null) {
			return "rediret:/Patient";
			
		}
		List<Users> doctorList=userRepo.findAllByRole(UserROle.Doctor);
		model.addAttribute("doctorList", doctorList);
		
		
		     
		
		Appointment appointment=new Appointment();
		model.addAttribute("appointment", appointment);
		return "Patient/BookAppointment";
	}
	
	
	
	
	@PostMapping("/Bookappointment")
	public String appointmeh(@ModelAttribute("appointment") Appointment appointment,RedirectAttributes attributes) {
		try {
			
			
			Users patient =(Users)  session.getAttribute("loggedInPatient");
			
			
			appointment.setPatient(patient);
			appointment.setBookedAt(LocalDateTime.now());
			appointment.setDepartment(appointment.getDoctor().getSpeciallization());
			appointment.setStatus(AppointmentStatus.PENDING);
			
			
			appointmentRepo.save(appointment);
			attributes.addFlashAttribute("msg", "Appointment successful");
			
			return "redirect:/Patient/Bookappointment";
		} catch (Exception e) {
			attributes.addFlashAttribute("msg", "Error:"+e.getMessage());
			
			return "redirect:/Patient/Bookappointment";
		}
	}
	
	
	@GetMapping("/VeiwAppointment")
	public String showVeiwAppointment(Model model) {
		if (session.getAttribute("loggedInPatient")==null) {
			return "redirect:/Patient";
			
		}
		
		Users patient=(Users) session.getAttribute("loggedInPatient");
		List<Appointment> appointments=appointmentRepo.findAllByPatient(patient);
		model.addAttribute("appointments", appointments);
	    
		
		
		return "Patient/VeiwAppointment";
	}
	

	
	
	
	
	
	
	@GetMapping("/Logout")
	public String logout(RedirectAttributes attributes) {
		session.removeAttribute("loggedInPatient");
		attributes.addFlashAttribute("msg", "Logout Successful");
		return "redirect:/Patient";

	}

	@GetMapping("/ChangePassword")
	public String Changepassword() {
		if (session.getAttribute("loggedInPatient") == null) {
			return "redirect:/Patient";
		}

		return "Patient/ChangePassword";

	}

	@PostMapping("/ChangePassword")
	public String changepasssword(HttpServletRequest request, RedirectAttributes attributes) {

		try {
			String oldPass = request.getParameter("oldPassword");
			String newPass = request.getParameter("newPassword");
			String confirmPass = request.getParameter("confirmPassword");

			if (!newPass.equals(confirmPass)) {
				attributes.addFlashAttribute("msg", "New Password and confirm Password are not Same!");
				return "redirect:/Patient/ChangePassword";
			}
			Users admin = (Users) session.getAttribute("loggedInPatient");
			if (oldPass.equals(admin.getPassword())) {
				admin.setPassword(confirmPass);
				userRepo.save(admin);
				session.removeAttribute("loggedInPatient");
				attributes.addFlashAttribute("msg", "Password Successfully Change");
				return "redirect:/Patient";

			} else {
				attributes.addFlashAttribute("msg", "Invalid Old Password");

			}

			return "redirect:/Patient/ChangePassword";

		} catch (Exception e) {
			attributes.addFlashAttribute("msg", "Error :" + e.getMessage());
			return "redirect:/Patient/ChangePassword";
		}
	}

	
	
	
	
@GetMapping("/ViewPrescription")
	private String showprescription(Model model) {
	if (session.getAttribute("loggedInPatient") == null) {
		return "redirect:/Patient";
	}
	Users patient=(Users) session.getAttribute("loggedInPatient");
List<Prescription> prescriptions=prescriptionRepo.findAllByPatient(patient);

model.addAttribute("prescriptions", prescriptions);
	
		return "Patient/ViewPrescription";
	}
	


}
