package com.myproject.PGIVirtualcare.Controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.myproject.PGIVirtualcare.API.SendAutoEmail;
import com.myproject.PGIVirtualcare.Model.Appointment;
import com.myproject.PGIVirtualcare.Model.Appointment.AppointmentStatus;
import com.myproject.PGIVirtualcare.Model.Enquiry;
import com.myproject.PGIVirtualcare.Model.Users;
import com.myproject.PGIVirtualcare.Model.Users.UserROle;
import com.myproject.PGIVirtualcare.Model.Users.UserStatus;
import com.myproject.PGIVirtualcare.Repository.AppointmentRepository;
import com.myproject.PGIVirtualcare.Repository.EnquiryRepository;
import com.myproject.PGIVirtualcare.Repository.PrescriptionRepository;
import com.myproject.PGIVirtualcare.Repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/Admin")
public class AdminController {

	@Autowired
	private HttpSession session;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private EnquiryRepository enquiryRepo;
	
	@Autowired
	private AppointmentRepository appointmentRepo;
	
	@Autowired
	private SendAutoEmail  sendAutoEmail;
	
@Autowired
	private PrescriptionRepository prescriptionRepo;
	
	@GetMapping("/AdminDashboard")
	public String showAdminDashboard(Model model) {
		if (session.getAttribute("loggedInAdmin") == null) {
			return "redirect:/Admin";
		}
		model.addAttribute("totalDoctor",userRepo.countByRole(UserROle.Doctor));
		model.addAttribute("totalPatient", userRepo.countByRole(UserROle.PATIENT));
		model.addAttribute("totalAppointment", appointmentRepo.count());
		model.addAttribute("totalPrescription", prescriptionRepo.count());
		model.addAttribute("approvedAppointment", appointmentRepo.countByStatus(AppointmentStatus.APPROVED)); 
		model.addAttribute("canceledAppointment", appointmentRepo.countByStatus(AppointmentStatus.REJECTED));
		return "Admin/AdminDashboard";

	}

	@GetMapping("/ManagePatients")
	public String showManagePatients(Model model) {
		if (session.getAttribute("loggedInAdmin") == null) {
			return "redirect:/Admin";
		}
		List<Users> patientList = userRepo.findAllByRole(UserROle.PATIENT);
		model.addAttribute("patientList", patientList.reversed());

		return "Admin/ManagePatient";

	}

	
	@GetMapping("/PatientStatus")
	public String updatepatientstatus(@RequestParam("id") long id ,RedirectAttributes attributes) {
		try {
			
			Users patient=userRepo.findById(id).get();
			if (patient.getStatus().equals(UserStatus.PENDING)) {
				patient.setStatus(UserStatus.APPROVED);
				userRepo.save(patient);
				sendAutoEmail.SendConfirmationEmail(patient);
			}
			else if (patient.getStatus().equals(UserStatus.APPROVED)) {
				patient.setStatus(UserStatus.DISABLE);
				userRepo.save(patient);
			}
			else {
				patient.setStatus(UserStatus.APPROVED);
				userRepo.save(patient);
			}
			
			
			attributes.addFlashAttribute("msg", "User Status Successfully Updated");
			return "redirect:/Admin/ManagePatients";
		} catch (Exception e) {
			return "redirect:/Admin/ManagePatients";
		}
		
		
		
		
	}
	
	
	
	@GetMapping("/DeletePatient")
	public String DeletePatient(@RequestParam("id") long id) {

		userRepo.deleteById(id);
		return "redirect:/Admin/ManagePatients";
	}

	@GetMapping("/Enquiries")
	public String showEnquiries(Model model) {
		if (session.getAttribute("loggedInAdmin") == null) {
			return "redirect:/Admin";
		}
		List<Enquiry> Elist = enquiryRepo.findAll();
		model.addAttribute("Elist", Elist);
		return "Admin/Enquiries";

	}

	@GetMapping("/DeleteEn")
	public String DeleteEn(@RequestParam("id") long id) {

		enquiryRepo.deleteById(id);
		return "redirect:/Admin/Enquiries";
	}

	@GetMapping("/AddDoctors")
	public String showAddDoctorspage(Model model) {
		if (session.getAttribute("loggedInAdmin") == null) {
			return "redirect:/Admin";
		}

		Users doctor = new Users();
		model.addAttribute("doctor", doctor);
		return "Admin/AdDDoctors";

	}

	@PostMapping("/AddDoctors")
	public String AddDoctors(@ModelAttribute("doctor") Users doctor, RedirectAttributes attributes) {

		try {

			if (userRepo.existsByEmail(doctor.getEmail())) {
				attributes.addFlashAttribute("msg", "user already exist by this email");
				return "redirect:/Admin/AddDoctors";
			}
			doctor.setRole(UserROle.Doctor);
			doctor.setStatus(UserStatus.APPROVED);
			doctor.setRegDate(LocalDateTime.now());
			userRepo.save(doctor);
			attributes.addFlashAttribute("msg", "Doctors Successfully Added");

			return "redirect:/Admin/AddDoctors";
		} catch (Exception e) {
			attributes.addFlashAttribute("msg", "Error :" + e.getMessage());
			return "redirect:/Admin/AddDoctors";
		}
	}

	@GetMapping("/Logout")
	public String logout(RedirectAttributes attributes) {
		session.removeAttribute("loggedInAdmin");
		attributes.addFlashAttribute("msg", "Logout Successful");
		return "redirect:/Admin";

	}

	@GetMapping("/ChangePassword")
	public String Changepassword() {
		if (session.getAttribute("loggedInAdmin") == null) {
			return "redirect:/Admin";
		}

		return "Admin/ChangePassword";

	}

	@PostMapping("/ChangePassword")
	public String changepasssword(HttpServletRequest request, RedirectAttributes attributes) {

		try {
			String oldPass = request.getParameter("oldPassword");
			String newPass = request.getParameter("newPassword");
			String confirmPass = request.getParameter("confirmPassword");

			if (!newPass.equals(confirmPass)) {
				attributes.addFlashAttribute("msg", "New Password and confirm Password are not Same!");
				return "redirect:/Admin/ChangePassword";
			}
			Users admin = (Users) session.getAttribute("loggedInAdmin");
			if (oldPass.equals(admin.getPassword())) {
				admin.setPassword(confirmPass);
				userRepo.save(admin);
				session.removeAttribute("loggedInAdmin");
				attributes.addFlashAttribute("msg", "Password Successfully Change");
				return "redirect:/Admin";

			} else {
				attributes.addFlashAttribute("msg", "Invalid Old Password");

			}

			return "redirect:/Admin/ChangePassword";

		} catch (Exception e) {
			attributes.addFlashAttribute("msg", "Error :" + e.getMessage());
			return "redirect:/Admin/ChangePassword";
		}
	}

	@GetMapping("/ViewDoctors")
	public String showAddDoctor(Model model) {
		if (session.getAttribute("loggedInAdmin") == null) {
			return "redirect:/Admin";
		}
		List<Users> DoctorList = userRepo.findAllByRole(UserROle.Doctor);
		model.addAttribute("DoctorList", DoctorList);

		return "Admin/ViewDoctors";

	}
	
	@GetMapping("/DoctorStatus")
	public String updateDoctorStatus(@RequestParam("id") long id ,RedirectAttributes attributes) {
		try {
			
			Users doctor=userRepo.findById(id).get();
			if (doctor.getStatus().equals(UserStatus.PENDING)) {
				doctor.setStatus(UserStatus.APPROVED);
				userRepo.save(doctor);
				sendAutoEmail.SendConfirmationEmail(doctor);
			}
			else if (doctor.getStatus().equals(UserStatus.APPROVED)) {
				doctor.setStatus(UserStatus.DISABLE);
				userRepo.save(doctor);
				sendAutoEmail.SendConfirmationEmail(doctor);
			}
			else {
				doctor.setStatus(UserStatus.APPROVED);
				userRepo.save(doctor);
			}
			
			
			attributes.addFlashAttribute("msg", "User Status Successfully Updated");
			return "redirect:/Admin/ViewDoctors";
		} catch (Exception e) {
			return "redirect:/Admin/ViewDoctors";
		}
		
		
		
		
	}
	
	

	@GetMapping("/DeleteDoctor")
	public String DeleteDoctor(@RequestParam("id") long id) {

		userRepo.deleteById(id);
		return "redirect:/Admin/ViewDoctors";
	}

	@GetMapping("/ViewAppointments")
	 public String veiwappointment(Model model) {
		if (session.getAttribute("loggedInAdmin") == null) {
			return "redirect:/Admin";
		}
		List<Appointment> Vlist=appointmentRepo.findAll();
		model.addAttribute("Vlist", Vlist);
		
		 
		 
		 
		 return "Admin/VeiwAppointments";
	 }
	
	
	
}
