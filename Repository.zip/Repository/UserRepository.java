package com.myproject.PGIVirtualcare.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myproject.PGIVirtualcare.Model.Users;
import com.myproject.PGIVirtualcare.Model.Users.UserROle;

public interface UserRepository extends JpaRepository<Users , Long> {

	boolean existsByEmail(String email);

	Users findByEmail(String email);

	List<Users> findAllByRole(UserROle patient);

	Object countByRole(UserROle doctor);

}
