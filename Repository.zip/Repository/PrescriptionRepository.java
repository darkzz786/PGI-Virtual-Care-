package com.myproject.PGIVirtualcare.Repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myproject.PGIVirtualcare.Model.Prescription;
import com.myproject.PGIVirtualcare.Model.Users;

public interface PrescriptionRepository extends JpaRepository<Prescription, Long> {

	List<Prescription> findAllByPatient(Users patient);



	

	

}
