package com.myproject.PGIVirtualcare.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myproject.PGIVirtualcare.Model.Enquiry;

public interface EnquiryRepository extends JpaRepository<Enquiry, Long> {
	

}
