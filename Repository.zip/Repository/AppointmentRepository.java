package com.myproject.PGIVirtualcare.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myproject.PGIVirtualcare.Model.Appointment;
import com.myproject.PGIVirtualcare.Model.Appointment.AppointmentStatus;
import com.myproject.PGIVirtualcare.Model.Users;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

	List<Appointment> findAllByPatient(Users patient);

	List<Appointment> findAllByDoctor(Users doctor);

	Object countByStatus(AppointmentStatus approved);



}
