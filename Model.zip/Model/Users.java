package com.myproject.PGIVirtualcare.Model;


import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table

public class Users {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private long id;
	
	
	
	
	private String name;
	private String contactNumber;
	
	
	
	@Column(unique  = true, nullable = false)
	private String email;
	private int age;
	
	
	@Column(length=500)
	private String address;
	@Column(nullable = false,length = 12)
	private String password;
	private String gender;
	
	
	
	private String adharNumber;
	private String Speciallization;
	private LocalDateTime regDate;
	@Column(length = 1000)
	private String profilePic;
	private String availableTime;
	@Enumerated(EnumType.STRING)
	
	public UserStatus status;
	@Enumerated(EnumType.STRING)
	public  UserROle   role;
	
	
	public enum UserStatus
	{
		PENDING,
		APPROVED,
		DISABLE
		
	}
	
	public enum UserROle
	{
		ADMIN,
		Doctor,
		PATIENT
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAdharNumber() {
		return adharNumber;
	}

	public void setAdharNumber(String adharNumber) {
		this.adharNumber = adharNumber;
	}

	public String getSpeciallization() {
		return Speciallization;
	}

	public void setSpeciallization(String speciallization) {
		Speciallization = speciallization;
	}

	public LocalDateTime getRegDate() {
		return regDate;
	}

	public void setRegDate(LocalDateTime regDate) {
		this.regDate = regDate;
	}

	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public String getAvailableTime() {
		return availableTime;
	}

	public void setAvailableTime(String availableTime) {
		this.availableTime = availableTime;
	}

	public UserStatus getStatus() {
		return status;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}

	public UserROle getRole() {
		return role;
	}

	public void setRole(UserROle role) {
		this.role = role;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
	

}
