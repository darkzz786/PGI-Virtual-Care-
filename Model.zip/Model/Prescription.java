package com.myproject.PGIVirtualcare.Model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Prescription {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long pid;

	@Column(nullable = false)
	private String medicationDetail;
	@Column(nullable = false, length = 500)
	private String advice;

	@Column(nullable = false, length = 500)
	private String diagonosis;
	private LocalDateTime prescirptionDate;

	@ManyToOne
	private Appointment appointment;

	@ManyToOne
	private Users patient;
	@ManyToOne
	private Users doctor;

	public Users getPatient() {
		return patient;
	}

	public void setPatient(Users patient) {
		this.patient = patient;
	}

	public Users getDoctor() {
		return doctor;
	}
	

	public void setDoctor(Users doctor) {
		this.doctor = doctor;
	}

	public long getPid() {
		return pid;
	}

	public void setPid(long pid) {
		this.pid = pid;
	}

	public String getMedicationDetail() {
		return medicationDetail;
	}

	public void setMedicationDetail(String medicationDetail) {
		this.medicationDetail = medicationDetail;
	}

	public String getAdvice() {
		return advice;
	}

	public void setAdvice(String advice) {
		this.advice = advice;
	}

	public String getDiagonosis() {
		return diagonosis;
	}

	public void setDiagonosis(String diagonosis) {
		this.diagonosis = diagonosis;
	}

	public LocalDateTime getPrescirptionDate() {
		return prescirptionDate;
	}

	public void setPrescirptionDate(LocalDateTime prescirptionDate) {
		this.prescirptionDate = prescirptionDate;
	}

	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}

}
